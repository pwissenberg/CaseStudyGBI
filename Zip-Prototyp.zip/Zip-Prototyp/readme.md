Einfach eine der HTML-Dateien anklicken und wie auf einer Website im Browser den Kurs interaktiv durchklicken.
Viel Spass dabei!

Euer

Ahmad & Paul
